﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Synthesis;
using Synthesis.Blade;
using Blade;

namespace $rootnamespace$
{
	public class $safeitemrootname$ : SynthesisPresenter<object, IStandardTemplateItem>
	{
		// TODO: fill in the model and template types in the SynthesisPresenter inheritance statement, then implement the abstract class
	}
}